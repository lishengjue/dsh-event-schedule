# 事件安排 · dsh-event-schedule

给 [DeepSeek Harness](https://github.com/deepseek-ai) 桌面版加的日历面板：**月历 / 周时间线 / 每日** 三个视图，
支持单日、多日、每周重复事项，可打钩完成，带小贴纸日记和还原点，还能从日程表文件批量导入工作安排。

插件装好后会出现在左侧栏（和「插件市场」「QQ 机器人」同一列），点开即是「事件安排」面板。
**首次安装是空日历**——没有任何内置数据，你可以从零开始记自己的事。

## 功能

### 三个视图
| 视图 | 说明 |
| --- | --- |
| **月历** | 整月网格，每格显示当天安排的小色条（最多 4 条，多了显示 +N）；单击某天在下方展开清单，**双击某天跳到「每日」**；顶部图例显示各类事项数量（只在月历显示，且只显示存在的那几类） |
| **时间线** | 周视图，周一~周日 × 08:00–21:00 时间轴；色块内「名称 + 时间」，重叠自动并排，当前时刻有红线；**双击表头日期跳到「每日」** |
| **每日** | 「今日课程」+「今日安排（时间线）」+「小贴纸」三栏；‹ › 切日期、一键回到今天 |

### 新增事项
- **安排类型**：自定义安排 / 工作安排
  - 自定义安排：随手记（交作业、开会、自习……）
  - 工作安排：多一个「从日程表文件导入」入口，导入后直接写入日历
- **重复方式**：单日 / 多日（小日历里点多个日期）/ 每周（选周几 + 起止日期）
- **时间**：开始–结束，可只填开始；不填开始 = 全天事项
- **事件 / 标注 / 重要性**（高·中·低）：标注里可以写地点、备注
- 底部有预览，提示这条会出现在哪些日子

### 完成与删除
- 自定义 / 工作 / 每周规律事项都可以打钩完成（按日期分别记录）
- 删除入口：月历下方清单、每日事项行、周视图点色块进编辑弹窗
- 多日事项可「只删这一天」或「删除全部」；每周重复可「只跳过这次」或「删除整个每周安排」

### 小贴纸 / 还原点
- 每日页右侧的小贴纸 = 当天日记 / 心情 / 备忘，月历格子里会用 ✦ 标出来
- 「还原点」手动给全部事项拍快照（最多 12 个），随时可还原；「清空全部」一键从空白开始

## 安装

### 方式一：作为本地插件放进 DSH profile（推荐）

1. 找到你的 profile 目录
   - Windows：`%USERPROFILE%\.dsh\profiles\desktop`
   - macOS / Linux：`~/.dsh/profiles/desktop`
2. 把本仓库放进 `<profile>/local-plugins/dsh-event-schedule`
3. 在 `<profile>/package.json` 的 `dependencies` 里加一行：
   ```json
   "dsh-event-schedule": "file:local-plugins/dsh-event-schedule"
   ```
4. 在 `<profile>/cordis.patch.yml` 里追加（没有就新建）：
   ```yaml
   - insert:
       - id: dsh-event-schedule
         name: dsh-event-schedule
   ```
5. 重启 DSH 桌面版，左侧栏就会出现「事件安排」

> `package.json` 请保存为无 BOM 的 UTF-8；`cordis.patch.yml` 必须是合法的 YAML 顶层数组。

### 方式二：市场安装

如果这个包已经发布到 DSH 插件市场 / npm，直接在「插件市场」里搜索 `dsh-event-schedule` 安装即可。

## 导入日程表文件（工作安排）

新增事项 → 选「工作安排」→ 选择文件…，支持三种格式：

### `.ics` 日历文件
读取 `SUMMARY / DTSTART / DTEND / LOCATION / DESCRIPTION`，并支持：

- `RRULE:FREQ=WEEKLY;BYDAY=MO,WE;UNTIL=20261231T000000Z` → 每周重复事项
- `EXDATE` → 跳过其中某几次
- `FREQ=DAILY` → 展开成多日事项（上限 120 天）
- 带 `Z` 的 UTC 时间会自动换算成本地时间

### `.csv` / `.txt` 表格
逗号、制表符、分号、竖线分隔都能识别；第一行可写表头，按列名自动匹配：

```csv
标题,日期,开始,结束,备注
部门例会,2026-11-12,14:00,15:30,A301
写周报,2026-11-13,,
```

- 列名可用：标题 / 事件 / 事项 / 名称 / title / summary / name；日期 / date；开始 / start；结束 / end；备注 / 地点 / 说明 / note / description
- 日期写法：`2026-11-12`、`2026/11/12`、`11月13日`、`20261112`
- 不写开始时间 = 全天事项；也可以写成 `09:00-11:00` 一列

### `.json`
```json
[
  { "title": "客户回访", "date": "2026-11-14", "start": "10:00", "end": "11:00", "note": "电话" }
]
```
也接受 `{ "events": [ ... ] }`；可用 `weekdays: [1,3] + from + until` 表示每周重复，`dates: ["2026-11-10", "2026-11-20"]` 表示多日。

解析不到东西时弹窗里会给出原因，不会写入脏数据。示例文件见 [`examples/`](examples/)。

## 数据存储

全部数据放在浏览器 localStorage（不上传服务器）：

| 键 | 内容 |
| --- | --- |
| `dsh-event-schedule:store:v1` | 全部事项 |
| `dsh-event-schedule:notes:v1` | 小贴纸（按日期） |
| `dsh-event-schedule:backups:v1` | 还原点（最多 12 个） |

换机器 / 备份时把这几个键导出即可；也可以点「还原点」手动快照后导出。

## 常用操作速查

| 想做的事 | 怎么做 |
| --- | --- |
| 加一条事 | 右上「＋ 新增事项」 |
| 批量导入日程 | 新增事项 → 工作安排 → 选择文件… |
| 看某天详情 | 月历单击该天；双击直接进「每日」 |
| 删掉每周重复里的某一次 | 点该事项 → 跳过这一天 |
| 记当天日记 | 每日页右侧「小贴纸」 |
| 误操作前先备份 | 右上「还原点」→ 新建还原点 |

## 开发说明

- `lib/index.js`：宿主侧入口（空实现，数据都在浏览器端）
- `lib/client.js`：全部 UI 逻辑，手写的 DSH client bundle 格式
  ```js
  window.__ModuleLoader__.load({ id: "dsh-event-schedule", factory: function (require) { /* ... */ } })
  ```
  通过 `ctx.inject(["layout"], ...)` 在 `main` slot 注册面板、在 `sidebar.panellist` 注册侧栏入口；
  样式用一段 `<style>` 注入（id `dsh-event-schedule-styles`），颜色跟随 DSH 主题变量。
- `cordis.patch.yml`：bundle patch，安装后自动把本包插入插件行。
- 改完 `lib/client.js` 后在 DSH 里 Ctrl+R 刷新页面即可看到效果。

## License

MIT，见 [LICENSE](LICENSE)。
